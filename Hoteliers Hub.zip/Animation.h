﻿#include <iostream> // header file for input and output on standard streams
#include <string>// header file for working with strings

using namespace std;
int menu();// function declaration for displaying the menu
void start(); // function declaration to start the program



void start() {
	system("cls");
	// continue the program here
}
int menu()
{
	
	cout << "\n\n\n\n\n\n";
	cout << "\t\t\t\t\t\t***************************************************\n";
	cout << "\t\t\t\t\t\t***************************************************\n";
	cout << "\t\t\t\t\t\t*              Hotelier's Hub                     *\n";
	cout << "\t\t\t\t\t\t***************************************************\n";
	cout << "\t\t\t\t\t\t*              (1) Add info to room               *\n";
	cout << "\t\t\t\t\t\t*              (2) Display All rooms              *\n";
	cout << "\t\t\t\t\t\t*              (3) Search by status               *\n";
	cout << "\t\t\t\t\t\t*              (4) Search by No room              *\n";
	cout << "\t\t\t\t\t\t*              (5) Update info                    *\n";
	cout << "\t\t\t\t\t\t*              (6) Delete  info                   *\n";
	cout << "\t\t\t\t\t\t*              (7) Delete All                     *\n";
	cout << "\t\t\t\t\t\t*              (8) Display number of operations   *\n";
	cout << "\t\t\t\t\t\t*                                                 *\n";
	cout << "\t\t\t\t\t\t***************************************************\n";
	cout << "\t\t\t\t\t\t*              (9) Exit                           *\n";
	cout << "\t\t\t\t\t\t***************************************************\n";
	cout << "\n\t\t\t\t\t\tEnter your choice: ";
	int a;
	cin >> a;
	system("cls");
	return a;

}
