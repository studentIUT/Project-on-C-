#include "Function.h"  // Including a custom header file, assumed to contain necessary declarations

template <typename T>  // Template class definition, using a generic type T
class Auth {
protected:
    T password = 0;          // Member variable for password
    string name;         // Member variable for name
    bool found = false;  // Flag to indicate if a match is found
    string line;         // String to hold each line read from file
    string savedUserName; // Saved username from file
    string savedPassword; // Saved password from file
public:

    void Sigin(string name, string password) {  // Function to sign in and save user information to a file
        ofstream File;
        File.open("security.txt", ios::app);    // Open file in append mode
        File << name << " " << password << "\n"; // Write name and password to file
        File.close();
    }

    bool Login(string name, string password) {  // Function to log in and check user credentials
        ifstream File("security.txt");           // Open file for reading
        while (getline(File, line)) {            // Read each line of the file
            string savedName = line.substr(0, line.find(" "));     // Extract saved username
            string savedNumber = line.substr(line.find(" ") + 1); // Extract saved password

            if (savedNumber == password) {       // Check if saved password matches input password
                found = true;                    // Set flag to true
                return true;                     // Return true for successful login
                break;                           // Exit loop
            }
        }

        if (found != true) {                      // If no match is found
            cout << "\t\t\t\tEntry not found." << endl; // Display message
        }

        File.close();                             // Close file
    }
};

int main() {
    int choice = 0;                              // Variable to hold user choice
    string a;                                    // String variable
    char name1[20];                              // Character array for room name
    string name, password;                       // String variables for name and password
    bool login;                                  // Boolean variable to track login status
    Hotel_Book obj1;                             // Object of Hotel_Book class
    Auth <int> s;                                // Object of Auth class with integer template type
    do {
        // Starting the program
        cout << "Signin or Login? " << endl;
        cout << "Enter signin or login: ";
        cin >> a;
        cout << endl;
        if (a == "signin") {                          // If user chooses to sign in
            cout << "enter name: ";
            cin >> name;                              // Get username
            cout << endl;
            cout << "enter password: ";
            cin >> password;                          // Get password
            cout << endl;
            s.Sigin(name, password);                  // Call sign-in function
            cout << "Succesfully saved    " << endl;  // Display success message
        }
        else if (a == "login") {                      // If user chooses to log in
            cout << "enter name: ";
            cin >> name;                              // Get username
            cout << endl;
            cout << "enter password: ";
            cin >> password;                          // Get password
            cout << endl;
            login = s.Login(name, password);          // Call login function
            if (login == true) {                      // If login is successful
                start();                              // Call start function

                // Displaying the menu and getting the user's choice
                choice = menu();



                do {
                    // Depending on the user's choice, perform a certain action
                    if (choice == 1) {
                        cout << "Enter new room's information: " << endl;
                        obj1.newrecord();             // Add a new room's information
                        cout << endl << endl;
                        system("pause");
                        system("cls");
                    }
                    else if (choice == 2) {
                        obj1.display();               // Display all rooms
                        cout << endl << endl;
                        system("pause");
                        system("cls");
                    }
                    else if (choice == 3) {
                        obj1.searchroom();            // Search for a room by status
                        cout << endl << endl;
                        system("pause");
                        system("cls");
                    }
                    else if (choice == 4) {
                        cout << "Enter number of room: ";
                        cin >> name1;
                        obj1.display(name1);         // Display a room by status
                        cout << endl << endl;
                        system("pause");
                        system("cls");
                    }
                    else if (choice == 5) {
                        obj1.updateinfo();           // Update room information
                        cout << endl << endl;
                        system("pause");
                        system("cls");
                    }
                    else if (choice == 6) {
                        obj1.deleterec();            // Delete a room
                        cout << endl << endl;
                        system("pause");
                        system("cls");
                    }
                    else if (choice == 7) {
                        int i;
                        cout << "Are you sure? (press 1 to delete all or press 0 to cancel)" << endl << "Your answer: ";
                        cin >> i;
                        if (i == 1) {
                            // Delete all rooms
                            ofstream ofs("room.txt", ofstream::out | ofstream::trunc);
                            ofs.close();
                            cout << "Deleted successfully!" << endl;
                            cout << endl << endl;
                            ofstream ofes("service.txt", ofstream::out | ofstream::trunc);
                            ofes.close();
                            cout << "Deleted successfully!" << endl;
                            cout << endl << endl;
                            system("pause");
                            system("cls");
                        }
                        else if (i == 0) {
                            // Cancel the operation
                            cout << "Canceled successfully" << endl;
                            cout << endl << endl;
                            system("pause");
                            system("cls");
                        }
                        else {
                            cout << "Invalid answer!!!";
                        }
                    }
                    else if (choice == 9) {
                        system("pause");                              // Pause the system
                        return 0;                     // Exit the program
                    }
                    else if (choice == 8) {
                        cout << "\n\nTotal changes after starting program: " << obj1.getTot_changes() << endl; // Display the total changes after starting program
                        cout << endl << endl;
                        system("pause");
                        system("cls");
                    }

                    choice = menu();                  // Display menu again

                } while (true);                        // Repeat until user chooses to exit
            }
            else {
                cout << "Invalid password  " << endl; // Display message for invalid password
            }
        }
        system("pause");
        system("cls");
    }while (true);
                                      // Return 0 to indicate successful completion
}

