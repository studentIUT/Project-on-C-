﻿#include <iostream>        // Including necessary header files
#include <fstream>
#include <cstring>
#include <Windows.h>       // This header is not used in the code, consider removing it
#include "Animation.h"    // Custom header file, not provided, assumed to be user-defined
using namespace std;

// Base class Accommodation
class Accommodation {     // Defining a base class for accommodation
protected:
    char room[150] = {}, status[150] = {};  // Member variables for room and status
    char serv[150] = {}, name[150] = {};                     // Member variable for service
    char date[150] = {}, phone[150] = {};                     // Member variable for date and number
public:
    void getdata() {};       // Virtual function for getting data, to be implemented in derived classes
    void showdata() {};      // Virtual function for showing data, to be implemented in derived classes
    void showdata1() {};     // Virtual function for showing additional data, to be implemented in derived classes
    void display() {};       // Virtual function for displaying data, to be implemented in derived classes
    void updateinfo() {};    // Virtual function for updating information, to be implemented in derived classes
    void deleterec() {};     // Virtual function for deleting a record, to be implemented in derived classes
     ~Accommodation() {}       // Adding a virtual destructor for the base class
};

// Derived class Hotel_Book
class Hotel_Book : public Accommodation {   // Derived class inheriting from Accommodation
protected:
    static int tot_changes;                // Static variable to track total changes
    int count = 0;                         // Counter variable

public:
    Hotel_Book() {                         // Constructor for Hotel_Book class
        room[0] = '\0';                    // Initializing member variables
        status[0] = '\0';
        serv[0] = '\0';
        date[0] = '\0';
        name[0] = '\0';
        phone[0] = '\0';
    }

    int getTot_changes() const { return tot_changes; }  // Getter function for total changes

    void getdata()  {             // Implementation of virtual function to get data
    to:
        cout << "\nEnter room No : ";
        cin >> room;
        int b = atoi(room);               // Converting room to integer
        try {
            char result = checkroom(b);   // Checking room validity
        }
        catch (const std::invalid_argument& e) {   // Handling invalid argument exception
            cerr << "Room not found! " << e.what() << endl;
            goto to;                     // Jumping to label 'to' in case of exception
        }
        cout << "Enter room status : ";
        cin >> status;
        cout << "Enter date : ";
        cin >> date;
    }

    int checkroom(int room) {            // Function to check room validity
        if (room == 0) {                 // If room is not found
            throw invalid_argument("Room not found!");  // Throw an exception
        }
        return room;                      // Return room number
    }

    void getdata1() {                   // Function to get additional data
        cout << "\nEnter service : ";
        cin >> serv;
        cout << "Enter name : ";
        cin >> name;
        cout << "Enter phone number : ";
        cin >> phone;

    }

    void showdata()  {           // Implementation of virtual function to show data
        cout << "\n";
        cout << "Room No: " << room;
        cout << ", status: " << status;
        cout << ", on: " << date << " days";
        cout << "\tprice: " << atoi(date) * 20 << "$" << endl;  // Calculating price based on days
    }

    void showdata1()  {          // Implementation of virtual function to show additional data
        cout << "Service: " << serv << endl;
        cout << "Name: " << name << "\tPhone number: " << phone << endl;
    }

    char* getroom() { return room; }     // Getter function for room
    char* getstatus() { return status; } // Getter function for status
    char* getdate() { return date; }     // Getter function for date
    char* getserv() { return serv; }     // Getter function for service
    char* getname() { return name; }     // Getter function for name
    char* getphone() { return phone; }     // Getter function for phone


    void update(char* rm, char* stat, char* dt) {  // Function to update information
        strcpy_s(room, rm);
        strcpy_s(status, stat);
        strcpy_s(date, dt);
    }

    void update(char* rm, char* stat) {  // Function overloading to update room and status
        strcpy_s(room, rm);
        strcpy_s(status, stat);
    }

    void update1(char* sv, char* nm, char* ph) {               // Function overloading to update service
        strcpy_s(serv, sv);
        strcpy_s(name, nm);
        strcpy_s(phone, ph);
    }

    void newrecord() {                    // Function to add a new record
        int found = 0;
        char st[150];
        char rm[150];
        char dat[150];
        char sv[150];
        char nm[150];
        char ph[150];
        getdata();                        // Get data for room, status, date, and service
        strcpy_s(rm, room);
        strcpy_s(st, status);
        strcpy_s(dat, date);
       

        fstream file;
        file.open("room.txt", ios::in | ios::app | ios::binary);
        while (file.read((char*)this, sizeof(*this))) {
            if (strcmp(rm, getroom()) == 0) {
                found = 1;
                break;
            }
        }
        file.clear();
        file.close();
        if (found == 1)
            cout << "\n\n---Room already exists---\n";
        else {
            file.open("room.txt", ios::app | ios::binary);
            update(rm, st, dat);
            file.write((char*)this, sizeof(*this));
            file.clear();
            file.close();
            cout << "Record Added Successfully\n";

            tot_changes++;                 // Increment the changes counter after adding a new record
        

        getdata1();
        strcpy_s(sv, serv);
        strcpy_s(nm, name);
        strcpy_s(ph, phone);

        fstream fil;
        fil.open("service.txt", ios::in | ios::app | ios::binary);
        update1(sv, nm, ph);
        fil.write((char*)this, sizeof(*this));
        fil.clear();
        fil.close();
        cout << "Record Added Successfully\n";
        }
    }

    void display()  {             // Implementation of virtual function to display all records
        fstream file, fil;
        file.open("room.txt", ios::in | ios::binary);
        fil.open("service.txt", ios::in | ios::binary);
        while (file.read((char*)this, sizeof(*this))) {
            showdata();
            if (fil.read((char*)this, sizeof(*this))) {
                showdata1();
            }
        }
        file.clear();
        file.close();
        fil.clear();
        fil.close();
    }

    void display(char* rm) {              // Function overloading to display records based on room
        int found = 0;
        fstream file;
        fstream fil;

        file.open("room.txt", ios::ate | ios::in | ios::out | ios::binary);
        file.seekg(0, ios::beg);
        fil.open("service.txt", ios::ate | ios::in | ios::out | ios::binary);
        fil.seekg(0, ios::beg);
        while (file.read((char*)this, sizeof(*this))) {
            if (strcmp(rm, getroom()) == 0) {
                if (!file.eof()) {
                    showdata();
                    while (fil.read((char*)this, sizeof(*this))) {
                        if (strcmp(rm, getroom()) == 0) {
                            if (!fil.eof())
                                showdata1();
                        }
                    }
                }
                found = 1;
            }
        }
        file.clear();
        if (found == 0)
            cout << "\n\n---Record Not found---\n";
        file.close();
        fil.clear();
        fil.close();
    }

    void searchroom() {                   // Function to search rooms based on status
        char rm[150];
        cout << "\n\nEnter room status : ";
        cin >> rm;
        fstream file("room.txt", ios::in | ios::binary);
        fstream fil;
        fil.open("service.txt", ios::ate | ios::in | ios::out | ios::binary);
        fil.seekg(0, ios::beg);
    link:
        while (file.read((char*)this, sizeof(*this))) {
            if (strcmp(rm, getstatus()) == 0) {
                if (!file.eof()) {
                    showdata();
                    while (fil.read((char*)this, sizeof(*this))) {
                        if (strcmp(rm, getstatus()) == 0) {
                            if (!fil.eof())
                                showdata1();
                            goto link;
                        }
                    }
                }
            }
        }
        file.clear();
        file.close();
    }

    void updateinfo()  {         // Implementation of virtual function to update hotel information
        int k;
        fstream file;
        file.open("room.txt", ios::ate | ios::in | ios::out | ios::binary);
        cout << "Enter 1 to update room No: " << endl;
        cout << "Enter 2 to update status: " << endl;
        cin >> k;
        if (k == 1) {                      // If updating room number
            char c = 0, ch, rm[150], newrm[150], st[150];
            int cnt = 0, found = 0;
            cout << "\n\nEnter room No : ";
            cin >> rm;
            file.seekg(0, ios::beg);
            while (file.read((char*)this, sizeof(*this))) {
                cnt++;
                if (strcmp(rm, getroom()) == 0) {
                    found = 1;
                    break;
                }
            }
            file.clear();
            if (found == 0)
                cout << "\n\n---Record Not found---\n";
            else {
                strcpy_s(st, status);
                int location = (cnt - 1) * sizeof(*this);
                cin.get(ch);
                if (file.eof())
                    file.clear();
                cout << "Enter New room No: ";
                cin >> newrm;
                file.seekp(location);
                update(newrm, st);
                file.write((char*)this, sizeof(*this));
                file.flush();
            }
        }
        if (k == 2) {                      // If updating room status
            char c = 0, ch, rm[150], newst[150];
            int cnt = 0, found = 0;
            cout << "\n\nEnter room number : ";
            cin >> rm;
            file.seekg(0, ios::beg);
            while (file.read((char*)this, sizeof(*this))) {
                cnt++;
                if (strcmp(rm, getroom()) == 0) {
                    found = 1;
                    break;
                }
            }
            file.clear();
            if (found == 0)
                cout << "\n\n---Record Not found---\n";
            else {
                strcpy_s(rm, room);
                int location = (cnt - 1) * sizeof(*this);
                cin.get(ch);
                if (file.eof())
                    file.clear();
                cout << "Enter New room status: ";
                cin >> newst;
                tot_changes++;
                file.seekp(location);
                update(rm, newst);
                file.write((char*)this, sizeof(*this));
                file.flush();
            }
        }
        file.clear();
        file.close();
    }

    void deleterec() {                   // Function to delete a record
        char bb[150];
        cout << "Enter the name of the record which is to be deleted: ";
        cin >> bb;
        int found = 0;

        // Delete record from room.txt
        fstream file("room.txt", ios::in | ios::binary);
        fstream fout("tempfile.txt", ios::out | ios::binary);
        while (file.read((char*)this, sizeof(*this))) {
            if (strcmp(bb, getroom()) != 0) {
                fout.write((char*)this, sizeof(*this));
            }
            else {
                found = 1;
            }
        }
        fout.close();
        file.close();

        if (found) {
            remove("room.txt");
            if (rename("tempfile.txt", "room.txt") != 0) {
                perror("Error renaming file");
            }
            cout << "RECORD DELETED FROM room.txt" << endl;

            // Delete corresponding record from service.txt
            fstream serviceFile("service.txt", ios::in | ios::binary);
            fstream tempServiceFile("temp_service.txt", ios::out | ios::binary);
            while (serviceFile.read((char*)this, sizeof(*this))) {
                if (strcmp(bb, getroom()) != 0) {
                    tempServiceFile.write((char*)this, sizeof(*this));
                }
            }
            tempServiceFile.close();
            serviceFile.close();

            remove("service.txt");
            if (rename("temp_service.txt", "service.txt") != 0) {
                perror("Error renaming file");
            }
            cout << "CORRESPONDING RECORD DELETED FROM service.txt" << endl;
        }
        else {
            cout << "RECORD NOT FOUND" << endl;
        }

        tot_changes = found ? tot_changes - 1 : tot_changes; // Update the value of the static variable tot_contacts
    }
};
int Hotel_Book::tot_changes;            // Definition of static variable tot_changes










